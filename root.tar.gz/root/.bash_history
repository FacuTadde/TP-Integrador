 poweroff
 poweroff
hostnamectl set-hostname TPServer
hostname
nano /etc/apt/sources.list
nano /etc/apt/sources.list
vi /etc/apt/sources.list
g
gg
vi /etc/apt/sources.list
vi /etc/apt/sources.list
cat /etc/apt/sources.list
clear
apt update && apt full-upgrade -y
reboot
su - palermo
whoami
cat /etc/apt/sources.list
v1 /etc/network/interfaces
vi /etc/network/interfaces
vi /etc/network/interfaces
vi /etc/network/interfaces
systemctl restart networking
systemctl status networking.service
ip link set enp0s3 down
ip addr flush dev enp0s3
ip addr add 192.168.0.50/24 dev enp0s3
ip link set enp0s3 up
ip route add default via 192.168.0.1
ip a
ping 192.168.0.1
ip a
apt install openssh-server -y
systemctl start ssh
systemctl enabler ssh
systemctl enable ssh
systemctl status ssh
vi /etc/ssh/sshd_config
i
vi /etc/ssh/sshd_config
systemctl restart ssh
cat /etc/debian_version
ip a
nano /etc/network/interfaces
nano /etc/network/interfaces
cat /etc/network/interfaces
apt install nano -y
nano /etc/network/interfaces
clear
systemctl restart networking
systemctl restart networking
systemctl restart networking.service
systemctl status networking.service
journalctl -xeu networking.service
cat /etc/network/interfaces
v1 etc/network/interfaces
vi etc/network/interfaces
vi etc/network/interfaces
vi etc/network/interfaces
vi etc/network/interfaces
su -
cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian bookworm main contrib non-free
deb http://deb.debian.org/debian bookworm-updates main contrib non-free
deb http://security.debian.org/debian-security bookworm-security main contrib non-free
EOF

cat /etc/apt/sources.list
apt update && apt full-upgrade -y
   ip a
ip a
cat /etc/debian_version
reboot
cat /etc/debian_version
apt install apache2 php libapache2-mod-php -y
systemctl status apache2
clear
cp /root/index.php /var/www/html/
cp /root/logo.png /var/www/html/
cp /root/index.php /var/www/html/
ls /root/
cat > /root/index.php << 'EOF'
<?php
echo "<h1>Bienvenido al servidor TP - Universidad de Palermo</h1>";
echo "<img src='logo.png' alt='Logo'>";
phpinfo();
?>
EOF

ls -la /root/
cp /root/index.php /var/www/html/
touch /root/logo.png
cp /root/logo.png /var/www/html/
cat > /root/db.sql << 'EOF'
CREATE DATABASE IF NOT EXISTS tppalermo;
USE tppalermo;
CREATE TABLE IF NOT EXISTS prueba (id INT PRIMARY KEY, nombre VARCHAR(50));
INSERT INTO prueba VALUES (1, 'test');
EOF

ls /var/www/html/
scp C:\Users\TuUsuario\Downloads\index.php root@192.168.0.50:/root/
scp C:\Users\TuUsuario\Downloads\logo.png root@192.168.0.50:/root/
scp C:\Users\TuUsuario\Downloads\db.sql root@192.168.0.50:/root/
scp C:\Users\TuUsuario\Downloads\clave_publica.pub root@192.168.0.50:/root/
scp C:\Users\TuUsuario\Downloads\clave_privada.txt root@192.168.0.50:/root/
scp C:\Users\facun\Downloads\index.php root@192.168.0.50:/root/
exit
ls -la /root/
clear
cp /root/index.php /var/www/html/
cp /root/logo.png /var/www/html/
ls /var/www/html/
systemctl restart apache2
systemctl status apache2
apt install mariadb-server -y
mysql < /root/db.sqlç
mysql < /root/db.sql
mysql -e "SHOW DATABASES;"
mysql -e "USE ingenieria; SHOW TABLES;"
rm /var/www/html/index.html
php -r "mysqli_connect('localhost', 'lcars', 'NCC1701D', 'ingenieria') or die(mysqli_connect_error());"
apt install php-mysql -y
systemctl restart apache2
clear
cp /root/clave_publica.pub /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys
chmod 700 /root/.ssh
grep -E "PubkeyAuthentication|AuthorizedKeysFile" /etc/ssh/sshd_config
systemctl restart ssh
ssh -i C:\Users\facun\Downloads\clave_privada.txt root@192.168.0.50
icacls C:\Users\facun\Downloads\clave_privada.txt /inheritance:r /grant:r "facun:R"
sed -i 's/#PubkeyAuthentication yes/PubkeyAuthentication yes/' /etc/ssh/sshd_config
sed -i 's/#AuthorizedKeysFile/AuthorizedKeysFile/' /etc/ssh/sshd_config
systemctl restart ssh
shutdown now
